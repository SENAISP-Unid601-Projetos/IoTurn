#ifndef CONVERTER_H
#define CONVERTER_H

const char* floatToStr(float valor, int casasDecimais = 2);
const char* intToStr(int valor);

#endif
