#ifndef SENSOR_TEMPERATURA_H
#define SENSOR_TEMPERATURA_H

void startTemperature();
float readTemperature();

#endif